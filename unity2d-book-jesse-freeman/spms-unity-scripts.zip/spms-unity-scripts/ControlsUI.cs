﻿/**
 *  @ControlsUI.cs
 *  @version: 1.00
 *  @author: Jesse Freeman
 *  @date: Feb 3
 *  @copyright (c) 2012 Jesse Freeman, under The MIT License (see LICENSE)
 * 
 * 	-- For use with Weekend Code Project: Unity's New 2D Workflow book --
 *
 *  This script will display two textures on either side of the screen to
 *  let the player know what the controls are for the game.
 */

using UnityEngine;
using System.Collections;

public class ControlsUI : MonoBehaviour {

	public Texture leftArrow; // Texture for the left arrow
	public Texture rightArrow; // Texture for the right arrow
	public Vector2 offset = new Vector2(10, 20); // Display offset from edge of the screen

	void OnGUI () {

		// Test to see if leftArrow texture has been set before rendering
		if(leftArrow)
			GUI.DrawTexture (new Rect (offset.x, offset.y, leftArrow.width, leftArrow.height), leftArrow);

		// Test to see if leftArrow texture has been set before rendering
		if(rightArrow)
			GUI.DrawTexture (new Rect (Screen.width - rightArrow.width - offset.x, offset.y, rightArrow.width, rightArrow.height), rightArrow);

	}
}
