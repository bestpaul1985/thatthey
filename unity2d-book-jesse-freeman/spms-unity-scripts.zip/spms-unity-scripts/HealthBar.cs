﻿/**
 *  @ControlsUI.cs
 *  @version: 1.00
 *  @author: Jesse Freeman
 *  @date: Feb 3
 *  @copyright (c) 2012 Jesse Freeman, under The MIT License (see LICENSE)
 * 
 * 	-- For use with Weekend Code Project: Unity's New 2D Workflow book --
 *
 *  This script Visualizes the health value on a GameObject with the
 *  Health script attached to it.
 */

using UnityEngine;
using System.Collections;

public class HealthBar : MonoBehaviour {

	public Texture backgroundTexture;
	public Texture foregroundTexture;
	public Texture borderTexture;
	public Vector2 offset = new Vector2();
	public GameObject target;

	private int barWidth;
	private int barHeight;
	private Health targetHealthComponent;

	void Start(){
		barWidth = borderTexture.width;
		barHeight = borderTexture.height;

		targetHealthComponent = target.GetComponent<Health>();
	}

	void OnGUI () {

		var percent = ((double)targetHealthComponent.health / (double)targetHealthComponent.maxHealth);

		GUI.DrawTexture (new Rect (offset.x, offset.y, barWidth, barHeight), backgroundTexture);
		GUI.DrawTexture (new Rect (offset.x, offset.y, (int)System.Math.Round(barWidth * percent), barHeight), foregroundTexture);
		GUI.DrawTexture (new Rect (offset.x, offset.y, barWidth, barHeight), borderTexture);
	}
}
